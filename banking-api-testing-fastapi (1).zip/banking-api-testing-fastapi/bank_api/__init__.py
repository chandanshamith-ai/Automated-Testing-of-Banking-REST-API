"""Banking REST API - the System Under Test (SUT)."""
