"""FastAPI REST layer for the banking service (bearer-token authenticated).

Request bodies are read as raw JSON and validated by bank_api.service so that
every bad input produces one consistent 400 error format (FastAPI's default
422 validation errors are mapped to the same format).
"""
import hmac
import secrets

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from starlette.exceptions import HTTPException as StarletteHTTPException

from .service import Bank, BankError, NotFoundError, ValidationError

# Demo credentials (a real system would use hashed passwords in a database).
USERS = {"alice": "wonderland123", "bob": "builder456"}


class Unauthorized(BankError):
    status = 401
    code = "unauthorized"


class InvalidCredentials(BankError):
    status = 401
    code = "invalid_credentials"


bearer = HTTPBearer(auto_error=False, description="Paste the token returned by POST /auth/login")


def body_doc(properties: dict, required: list, example: dict) -> dict:
    """OpenAPI request-body description so Swagger UI shows an editable JSON body."""
    return {
        "requestBody": {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {"type": "object", "properties": properties, "required": required},
                    "example": example,
                }
            },
        }
    }


LOGIN_DOC = body_doc(
    {"username": {"type": "string"}, "password": {"type": "string"}},
    ["username", "password"],
    {"username": "alice", "password": "wonderland123"},
)
ACCOUNT_DOC = body_doc({"initial_deposit": {"type": "string"}}, [], {"initial_deposit": "500"})
AMOUNT_DOC = body_doc({"amount": {"type": "string"}}, ["amount"], {"amount": "100.00"})
TRANSFER_DOC = body_doc(
    {
        "from_account_id": {"type": "integer"},
        "to_account_id": {"type": "integer"},
        "amount": {"type": "string"},
    },
    ["from_account_id", "to_account_id", "amount"],
    {"from_account_id": 1, "to_account_id": 2, "amount": "1500.00"},
)


def error_response(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


async def json_body(request: Request) -> dict:
    try:
        data = await request.json()
    except Exception:
        raise ValidationError("Request body must be a JSON object") from None
    if not isinstance(data, dict):
        raise ValidationError("Request body must be a JSON object")
    return data


def require_int(data: dict, key: str) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValidationError(f"{key} must be an integer")
    return value


def parse_account_id(raw: str) -> int:
    """Non-numeric ids are treated as 'resource not found' (404), not a 422."""
    if not (raw.isascii() and raw.isdigit()):
        raise NotFoundError("Resource not found")
    return int(raw)


def create_app() -> FastAPI:
    app = FastAPI(title="Banking API", version="1.0.0")
    bank = Bank()
    tokens: dict = {}

    # ---- error handling: one JSON shape for everything --------------------
    @app.exception_handler(BankError)
    async def handle_bank_error(_request: Request, exc: BankError):
        return error_response(exc.status, exc.code, str(exc))

    @app.exception_handler(StarletteHTTPException)
    async def handle_http_error(_request: Request, exc: StarletteHTTPException):
        codes = {404: "not_found", 405: "method_not_allowed"}
        messages = {404: "Resource not found", 405: "Method not allowed"}
        return error_response(
            exc.status_code,
            codes.get(exc.status_code, "http_error"),
            messages.get(exc.status_code, str(exc.detail)),
        )

    @app.exception_handler(RequestValidationError)
    async def handle_validation_error(_request: Request, _exc: RequestValidationError):
        return error_response(400, "validation_error", "Invalid request")

    # ---- authentication dependency ---------------------------------------
    def current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer)) -> str:
        user = tokens.get(credentials.credentials) if credentials else None
        if user is None:
            raise Unauthorized("Missing or invalid bearer token")
        return user

    # ---- routes -----------------------------------------------------------
    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.post("/auth/login", openapi_extra=LOGIN_DOC)
    async def login(request: Request):
        data = await json_body(request)
        username, password = data.get("username"), data.get("password")
        if not isinstance(username, str) or not isinstance(password, str) or not username or not password:
            raise ValidationError("username and password are required")
        expected = USERS.get(username)
        if expected is None or not hmac.compare_digest(expected.encode(), password.encode()):
            raise InvalidCredentials("Invalid username or password")
        token = secrets.token_urlsafe(24)
        tokens[token] = username
        return {"token": token, "token_type": "Bearer"}

    @app.post("/accounts", status_code=201, openapi_extra=ACCOUNT_DOC)
    async def create_account(request: Request, user: str = Depends(current_user)):
        data = await json_body(request)
        return bank.open_account(user, data.get("initial_deposit", "0"))

    @app.get("/accounts/{account_id}")
    async def get_account(account_id: str, user: str = Depends(current_user)):
        return bank.get_account(parse_account_id(account_id), user)

    @app.post("/accounts/{account_id}/deposit", openapi_extra=AMOUNT_DOC)
    async def deposit(account_id: str, request: Request, user: str = Depends(current_user)):
        data = await json_body(request)
        return bank.deposit(parse_account_id(account_id), user, data.get("amount"))

    @app.post("/accounts/{account_id}/withdraw", openapi_extra=AMOUNT_DOC)
    async def withdraw(account_id: str, request: Request, user: str = Depends(current_user)):
        data = await json_body(request)
        return bank.withdraw(parse_account_id(account_id), user, data.get("amount"))

    @app.get("/accounts/{account_id}/transactions")
    async def transactions(account_id: str, user: str = Depends(current_user)):
        return {"transactions": bank.transactions(parse_account_id(account_id), user)}

    @app.post("/transfers", openapi_extra=TRANSFER_DOC)
    async def transfer(request: Request, user: str = Depends(current_user)):
        data = await json_body(request)
        from_id = require_int(data, "from_account_id")
        to_id = require_int(data, "to_account_id")
        return {"transfer": bank.transfer(from_id, to_id, user, data.get("amount"))}

    return app


app = create_app()  # for: uvicorn bank_api.app:app
