"""Core banking logic: the program module under test.

Business rules
--------------
* Money is handled with Decimal, never float, and always has 2 decimal places.
* A single amount must be > 0 and <= 50,000.00 (initial deposits may be 0).
* Transfers strictly above 1,000.00 carry a 0.5% fee (rounded half-up to the
  cent) that is charged to the sender on top of the transfer amount.
* An account can only be accessed by its owner (a transfer *destination* may
  belong to anyone).
* Balances can never go negative; a failed operation leaves all balances intact.
"""
from __future__ import annotations

import itertools
import threading
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

CENT = Decimal("0.01")
MAX_AMOUNT = Decimal("50000.00")
FEE_THRESHOLD = Decimal("1000.00")
FEE_RATE = Decimal("0.005")


class BankError(Exception):
    """Base class; carries the HTTP status and machine-readable code."""

    status = 400
    code = "bad_request"


class ValidationError(BankError):
    code = "validation_error"


class NotFoundError(BankError):
    status = 404
    code = "not_found"


class ForbiddenError(BankError):
    status = 403
    code = "forbidden"


class InsufficientFundsError(BankError):
    status = 422
    code = "insufficient_funds"


def parse_amount(value, *, allow_zero: bool = False) -> Decimal:
    """Validate a user supplied amount and return it as a 2dp Decimal."""
    if value is None or isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ValidationError("amount must be a number")
    if isinstance(value, str) and "_" in value:
        raise ValidationError("amount must be a number")
    try:
        amount = Decimal(str(value).strip())
    except InvalidOperation:
        raise ValidationError("amount must be a number") from None
    if not amount.is_finite():
        raise ValidationError("amount must be a finite number")
    if amount < 0:
        raise ValidationError("amount must not be negative")
    if amount == 0 and not allow_zero:
        raise ValidationError("amount must be greater than zero")
    if amount > MAX_AMOUNT:
        raise ValidationError(f"amount must not exceed {MAX_AMOUNT}")
    if amount.normalize().as_tuple().exponent < -2:
        raise ValidationError("amount cannot have more than 2 decimal places")
    return amount.quantize(CENT)


def transfer_fee(amount: Decimal) -> Decimal:
    """0.5% (half-up) for amounts strictly above the threshold, else 0.00."""
    if amount > FEE_THRESHOLD:
        return (amount * FEE_RATE).quantize(CENT, rounding=ROUND_HALF_UP)
    return Decimal("0.00")


@dataclass
class Account:
    id: int
    owner: str
    balance: Decimal = Decimal("0.00")
    history: list = field(default_factory=list)

    def snapshot(self) -> dict:
        return {"id": self.id, "owner": self.owner, "balance": str(self.balance)}

    def record(self, kind: str, amount: Decimal, **extra) -> None:
        self.history.append(
            {"type": kind, "amount": str(amount), "balance_after": str(self.balance), **extra}
        )


class Bank:
    """In-memory bank. All mutating operations are serialised by one lock."""

    def __init__(self) -> None:
        self._accounts: dict[int, Account] = {}
        self._ids = itertools.count(1)
        self._lock = threading.Lock()

    # -- helpers -----------------------------------------------------------
    def _find(self, account_id: int) -> Account:
        account = self._accounts.get(account_id)
        if account is None:
            raise NotFoundError(f"Account {account_id} not found")
        return account

    def _find_owned(self, account_id: int, requester: str) -> Account:
        account = self._find(account_id)
        if account.owner != requester:
            raise ForbiddenError("You do not own this account")
        return account

    # -- operations --------------------------------------------------------
    def open_account(self, owner: str, initial_deposit="0") -> dict:
        amount = parse_amount(initial_deposit, allow_zero=True)
        with self._lock:
            account = Account(id=next(self._ids), owner=owner)
            if amount > 0:
                account.balance = amount
                account.record("deposit", amount)
            self._accounts[account.id] = account
            return account.snapshot()

    def get_account(self, account_id: int, requester: str) -> dict:
        with self._lock:
            return self._find_owned(account_id, requester).snapshot()

    def deposit(self, account_id: int, requester: str, amount) -> dict:
        value = parse_amount(amount)
        with self._lock:
            account = self._find_owned(account_id, requester)
            account.balance += value
            account.record("deposit", value)
            return account.snapshot()

    def withdraw(self, account_id: int, requester: str, amount) -> dict:
        value = parse_amount(amount)
        with self._lock:
            account = self._find_owned(account_id, requester)
            if value > account.balance:
                raise InsufficientFundsError("Insufficient funds")
            account.balance -= value
            account.record("withdraw", value)
            return account.snapshot()

    def transfer(self, from_id: int, to_id: int, requester: str, amount) -> dict:
        value = parse_amount(amount)
        if from_id == to_id:
            raise ValidationError("Cannot transfer to the same account")
        with self._lock:
            source = self._find_owned(from_id, requester)
            target = self._find(to_id)
            fee = transfer_fee(value)
            if value + fee > source.balance:
                raise InsufficientFundsError("Insufficient funds (amount plus fee)")
            source.balance -= value + fee
            target.balance += value
            source.record("transfer_out", value, fee=str(fee), counterparty=to_id)
            target.record("transfer_in", value, counterparty=from_id)
            return {
                "from_account_id": from_id,
                "to_account_id": to_id,
                "amount": str(value),
                "fee": str(fee),
                "from_balance": str(source.balance),
            }

    def transactions(self, account_id: int, requester: str) -> list:
        with self._lock:
            return list(self._find_owned(account_id, requester).history)
