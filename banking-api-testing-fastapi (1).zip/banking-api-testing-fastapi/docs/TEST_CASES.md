# Formal Test Case Design

**SUT:** Banking REST API (`bank_api/`) - accounts, deposit, withdraw, transfers with fee, token auth.
**Techniques:** EP = Equivalence Partitioning, BVA = Boundary Value Analysis, DT = Decision Table,
ST = State Transition, EG = Error Guessing, SEC = Security/negative testing, E2E = Scenario testing.

**Business rules under test**
- R1: amount must be > 0 and <= 50,000.00 with at most 2 decimals (initial deposit may be 0)
- R2: withdrawal cannot exceed balance (balance never negative)
- R3: transfer fee = 0.5% (round half-up to cent) only when amount is **strictly greater** than 1,000.00; sender pays amount + fee, receiver gets amount
- R4: only the account owner can read or change an account; transfer destination can be anyone's
- R5: failed operations change no balance (atomicity)
- R6: all protected endpoints need a valid bearer token

Preconditions use: **A** = alice's account, **B** = bob's account, "logged in" = valid bearer token.

## 1. Unit tests - `tests/test_unit_service.py`

| Test ID | Precondition | Input | Expected output | Technique |
|---|---|---|---|---|
| UT-01 | none | `parse_amount("0.01")` | `0.01` (minimum accepted) | BVA |
| UT-02 | none | `parse_amount("50000")` | `50000.00` (maximum accepted) | BVA |
| UT-03 | none | `parse_amount(100)` (int) | `100.00` | EP |
| UT-04 | none | `parse_amount(12.5)` (float) | `12.50` | EP |
| UT-05 | none | `parse_amount(" 7.25 ")` | `7.25` | EP |
| UT-06 | none | `"0"` | ValidationError | BVA |
| UT-07 | none | `"-0.01"` | ValidationError | BVA |
| UT-08 | none | `"50000.01"` | ValidationError | BVA |
| UT-09 | none | `"1.001"` | ValidationError (3 decimals) | EP |
| UT-10 | none | `"abc"` | ValidationError | EP |
| UT-11 | none | `None` | ValidationError | EG |
| UT-12 | none | `True` | ValidationError (bool is an int in Python) | EG |
| UT-13 | none | `"NaN"` | ValidationError | EG |
| UT-14 | none | `"Infinity"` | ValidationError | EG |
| UT-15 | none | `""` | ValidationError | EG |
| UT-16 | none | `[1]` | ValidationError | EG |
| UT-17 | none | `parse_amount("0", allow_zero=True)` | `0.00` | BVA |
| UT-18 | empty bank | `open_account("alice")` | `{id:1, owner:alice, balance:"0.00"}` | EP |
| UT-19 | empty bank | `open_account("alice","250.50")` | balance `250.50`, history = [deposit] | EP |
| UT-20 | empty bank | open two accounts | ids 1 then 2 | EP |
| UT-21 | A balance 100 | deposit `25.5` | balance `125.50` | EP |
| UT-22 | A balance 100 | withdraw `100` | balance `0.00` | BVA |
| UT-23 | A balance 100 | withdraw `100.01` | InsufficientFunds; balance stays `100.00`; no new history | BVA, R5 |
| UT-24 | A balance 100 | withdraw `40.25` | balance `59.75` | EP |
| UT-25 | A 2000, B 0 | transfer `1000.00` | fee `0.00`; A `1000.00`; B `1000.00` | BVA, R3 |
| UT-26 | A 2000, B 0 | transfer `1000.01` | fee `5.00` (5.00005 rounded); A `994.99`; B `1000.01` | BVA, R3 |
| UT-27 | A 2000, B 0 | transfer `1001.00` | fee `5.01` (5.005 half-up, not banker's) | BVA, DT |
| UT-28 | A 1006.00 | transfer `1001.00` (needs 1006.01) | InsufficientFunds; A and B unchanged | BVA, R5 |
| UT-29 | A 1006.01 | transfer `1001.00` | success; A `0.00` | BVA |
| UT-30 | A 100 | transfer A to A | ValidationError | DT |
| UT-31 | A 100 | transfer to account 999 | NotFound; A unchanged | DT, R5 |
| UT-32 | A (alice), B (bob) | bob transfers from A | Forbidden; A unchanged | DT, R4 |
| UT-33 | A (alice) | bob reads A | Forbidden | DT, R4 |
| UT-34 | none | read account 42 | NotFound | EP |
| UT-35 | A 500, B 0 | withdraw 100, transfer 200 | A history: deposit, withdraw, transfer_out(fee 0.00); B history: transfer_in | ST |
| UT-36 | A 0 | 200 concurrent deposits of 1.00 (16 threads) | balance exactly `200.00` | EG (race condition) |

## 2. API tests - `tests/test_api_*.py`

| Test ID | Precondition | Request | Expected output | Technique |
|---|---|---|---|---|
| API-01 | none | `GET /health` | 200 `{"status":"ok"}` | EP |
| API-02 | none | login alice / correct password | 200, Bearer token | EP |
| API-03 | none | login alice / wrong password | 401 `invalid_credentials` | EP |
| API-04 | none | login unknown user | 401 | EP |
| API-05a-d | none | login with `{}`, no password, no username, empty strings | 400 `validation_error` | DT |
| API-06 | none | login with non-JSON body | 400 | EG |
| API-07 | none | login with numeric / list credentials | 400 | EG |
| API-08 | not logged in | `POST /accounts` | 401 `unauthorized` | R6 |
| API-09a-b | none | `Basic ...` header; `Bearer` with no token | 401 | EG |
| API-10 | none | `Bearer not-a-real-token` | 401 | EG |
| API-11 | alice logged in | `POST /accounts {}` | 201 `{id:1, owner:alice, balance:"0.00"}` | EP |
| API-12 | alice logged in | `POST /accounts {initial_deposit:100.5}` | 201, balance `100.50` | EP |
| API-13 | alice logged in | `initial_deposit: -5` | 400 | BVA |
| API-14 | A balance 10 | `GET /accounts/A` | 200, balance `10.00` | EP |
| API-15 | A (alice), bob logged in | bob `GET /accounts/A` | 403 `forbidden` | R4 |
| API-16 | alice logged in | `GET /accounts/999` | 404 JSON `not_found` | EP |
| API-17 | alice logged in | `GET /accounts/abc` | 404 JSON | EG |
| API-18 | A balance 10 | deposit `"5.25"` | 200, balance `15.25` | EP |
| API-19a-g | A balance 10 | deposit `0`, `-1`, `"abc"`, `50000.01`, `{}`, `null`, `"1.234"` | 400; balance stays `10.00` | BVA, EP, EG |
| API-20 | A balance 0 | deposit `50000` | 200, balance `50000.00` | BVA |
| API-21 | A balance 100 | withdraw `"30"` | 200, balance `70.00` | EP |
| API-22 | A balance 100 | withdraw `"100.01"` | 422 `insufficient_funds` | BVA |
| API-23 | A balance 100 | withdraw `"100"` | 200, balance `0.00` | BVA |
| API-24 | A (alice), bob logged in | bob deposits into A | 403; A unchanged | R4 |
| API-25 | A exists | `DELETE /accounts/A` | 405 JSON `method_not_allowed` | EG |
| API-26 | A 2000, B 0 | transfer `"1000.00"` | 200, fee `0.00` | BVA |
| API-27 | A 2000, B 0 | transfer `"1001.00"` | 200, fee `5.01`, sender balance `993.99` | BVA |
| API-28 | A 500 (alice), B 0 (bob) | alice transfers 200 to B | 200; bob sees `200.00` | EP |
| API-29 | A 50, B 5 | transfer `"50.01"` | 422; A `50.00`, B `5.00` | BVA, R5 |
| API-30 | A 50 | transfer A to A | 400 | DT |
| API-31 | A (alice), B (bob) | bob transfers from A | 403 | R4 |
| API-32 | A 50 | transfer to 999 | 404 | DT |
| API-33a-c | alice logged in | ids as `"1"`, `true`, `2.5` | 400 | EG |
| API-34a-c | alice logged in | missing amount / missing from id / `{}` | 400 | DT |
| API-35 | A 300, B 0 | transfer 100, then `GET /accounts/A/transactions` | `[deposit, transfer_out]`, counterparty = B | ST |
| API-36 | A (alice), bob logged in | bob reads A's transactions | 403 | R4 |
| API-37 | alice logged in | `POST /accounts` | `application/json`; keys exactly `id, owner, balance`; balance is a string | Contract |
| API-38 | both users | login, open, deposit 2000, withdraw 50.50, transfer 1500 | fee `7.50`; A `542.00`; B `1500.00`; A history has 4 entries | E2E |
| API-39 | A balance 0 | 200 sequential deposits | all 200 OK, balance `200.00`, total time < 5 s | Performance |
| API-40 | none | login with `' OR '1'='1` | 401 (no 500, no bypass) | SEC |

**Total: 90 executed test cases** (36 unit, 54 API) from 60 test functions.
