@echo off
REM Windows (cmd) one-command test run -> reports\
if not exist reports mkdir reports
python -m pytest --cov=bank_api --cov-branch --cov-report=term-missing --cov-report=html:reports/coverage --cov-report=xml:reports/coverage.xml --html=reports/report.html --self-contained-html --junitxml=reports/junit.xml --durations=10 -v %*
