#!/usr/bin/env bash
# One-command test run: executes the suite and generates all reports in ./reports
set -euo pipefail
mkdir -p reports
python -m pytest \
  --cov=bank_api --cov-branch \
  --cov-report=term-missing \
  --cov-report=html:reports/coverage \
  --cov-report=xml:reports/coverage.xml \
  --html=reports/report.html --self-contained-html \
  --junitxml=reports/junit.xml \
  --durations=10 \
  -v "$@"
