"""Shared fixtures. Every test gets a fresh app/bank, so tests are independent."""
import pytest
from fastapi.testclient import TestClient

from bank_api.app import create_app
from bank_api.service import Bank


@pytest.fixture
def bank():
    return Bank()


@pytest.fixture
def client():
    return TestClient(create_app())


def _login(client, username, password):
    response = client.post("/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['token']}"}


@pytest.fixture
def alice(client):
    return _login(client, "alice", "wonderland123")


@pytest.fixture
def bob(client):
    return _login(client, "bob", "builder456")


@pytest.fixture
def make_account(client):
    """Factory: create an account for the given auth headers, return its id."""

    def _make(headers, initial="0"):
        response = client.post("/accounts", json={"initial_deposit": initial}, headers=headers)
        assert response.status_code == 201
        return response.json()["id"]

    return _make
