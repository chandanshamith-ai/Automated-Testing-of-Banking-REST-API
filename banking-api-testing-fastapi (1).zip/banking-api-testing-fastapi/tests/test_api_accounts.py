"""API tests: account creation, deposit, withdraw, access control, contract."""
import pytest


def test_api11_create_account_returns_201_and_owner_is_caller(client, alice):
    response = client.post("/accounts", json={}, headers=alice)
    assert response.status_code == 201
    assert response.json() == {"id": 1, "owner": "alice", "balance": "0.00"}


def test_api12_create_account_with_initial_deposit(client, alice):
    response = client.post("/accounts", json={"initial_deposit": 100.5}, headers=alice)
    assert response.status_code == 201
    assert response.json()["balance"] == "100.50"


def test_api13_create_account_with_negative_initial_deposit_is_400(client, alice):
    response = client.post("/accounts", json={"initial_deposit": -5}, headers=alice)
    assert response.status_code == 400


def test_api14_get_own_account(client, alice, make_account):
    acct = make_account(alice, "10")
    response = client.get(f"/accounts/{acct}", headers=alice)
    assert response.status_code == 200
    assert response.json()["balance"] == "10.00"


def test_api15_get_someone_elses_account_is_403(client, alice, bob, make_account):
    acct = make_account(alice)
    response = client.get(f"/accounts/{acct}", headers=bob)
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "forbidden"


def test_api16_get_missing_account_is_404_json(client, alice):
    response = client.get("/accounts/999", headers=alice)
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"


def test_api17_non_numeric_account_id_is_404_json(client, alice):
    response = client.get("/accounts/abc", headers=alice)
    assert response.status_code == 404
    assert response.headers["content-type"].startswith("application/json")


def test_api18_deposit_updates_balance(client, alice, make_account):
    acct = make_account(alice, "10")
    response = client.post(f"/accounts/{acct}/deposit", json={"amount": "5.25"}, headers=alice)
    assert response.status_code == 200
    assert response.json()["balance"] == "15.25"


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param({"amount": 0}, id="API-19a"),
        pytest.param({"amount": -1}, id="API-19b"),
        pytest.param({"amount": "abc"}, id="API-19c"),
        pytest.param({"amount": 50000.01}, id="API-19d"),
        pytest.param({}, id="API-19e"),
        pytest.param({"amount": None}, id="API-19f"),
        pytest.param({"amount": "1.234"}, id="API-19g"),
    ],
)
def test_api19_deposit_with_invalid_amount_is_400(client, alice, make_account, payload):
    acct = make_account(alice, "10")
    response = client.post(f"/accounts/{acct}/deposit", json=payload, headers=alice)
    assert response.status_code == 400
    assert client.get(f"/accounts/{acct}", headers=alice).json()["balance"] == "10.00"


def test_api20_deposit_at_maximum_boundary_is_accepted(client, alice, make_account):
    acct = make_account(alice)
    response = client.post(f"/accounts/{acct}/deposit", json={"amount": 50000}, headers=alice)
    assert response.status_code == 200
    assert response.json()["balance"] == "50000.00"


def test_api21_withdraw_updates_balance(client, alice, make_account):
    acct = make_account(alice, "100")
    response = client.post(f"/accounts/{acct}/withdraw", json={"amount": "30"}, headers=alice)
    assert response.status_code == 200
    assert response.json()["balance"] == "70.00"


def test_api22_withdraw_more_than_balance_is_422(client, alice, make_account):
    acct = make_account(alice, "100")
    response = client.post(f"/accounts/{acct}/withdraw", json={"amount": "100.01"}, headers=alice)
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "insufficient_funds"


def test_api23_withdraw_exact_balance_leaves_zero(client, alice, make_account):
    acct = make_account(alice, "100")
    response = client.post(f"/accounts/{acct}/withdraw", json={"amount": "100"}, headers=alice)
    assert response.status_code == 200
    assert response.json()["balance"] == "0.00"


def test_api24_deposit_into_someone_elses_account_is_403(client, alice, bob, make_account):
    acct = make_account(alice, "10")
    response = client.post(f"/accounts/{acct}/deposit", json={"amount": 5}, headers=bob)
    assert response.status_code == 403
    assert client.get(f"/accounts/{acct}", headers=alice).json()["balance"] == "10.00"


def test_api25_unsupported_method_is_405_json(client, alice, make_account):
    acct = make_account(alice)
    response = client.delete(f"/accounts/{acct}", headers=alice)
    assert response.status_code == 405
    assert response.json()["error"]["code"] == "method_not_allowed"


def test_api37_response_contract_json_types(client, alice):
    response = client.post("/accounts", json={"initial_deposit": "1"}, headers=alice)
    body = response.json()
    assert response.headers["content-type"].startswith("application/json")
    assert set(body) == {"id", "owner", "balance"}
    assert isinstance(body["id"], int)
    assert isinstance(body["balance"], str)  # money is never a float
