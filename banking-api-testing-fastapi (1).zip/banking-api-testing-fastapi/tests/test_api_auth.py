"""API tests: health, login, token handling. IDs map to docs/TEST_CASES.md."""
import pytest


def test_api01_health_endpoint_is_public(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_api02_login_with_valid_credentials_returns_token(client):
    response = client.post("/auth/login", json={"username": "alice", "password": "wonderland123"})
    body = response.json()
    assert response.status_code == 200
    assert body["token_type"] == "Bearer"
    assert len(body["token"]) >= 20


def test_api03_login_with_wrong_password_is_401(client):
    response = client.post("/auth/login", json={"username": "alice", "password": "nope"})
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "invalid_credentials"


def test_api04_login_with_unknown_user_is_401(client):
    response = client.post("/auth/login", json={"username": "mallory", "password": "x"})
    assert response.status_code == 401


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param({}, id="API-05a"),
        pytest.param({"username": "alice"}, id="API-05b"),
        pytest.param({"password": "wonderland123"}, id="API-05c"),
        pytest.param({"username": "", "password": ""}, id="API-05d"),
    ],
)
def test_api05_login_with_missing_fields_is_400(client, payload):
    response = client.post("/auth/login", json=payload)
    assert response.status_code == 400
    assert response.json()["error"]["code"] == "validation_error"


def test_api06_login_with_non_json_body_is_400(client):
    response = client.post("/auth/login", content="not json", headers={"Content-Type": "text/plain"})
    assert response.status_code == 400


def test_api07_login_with_non_string_credentials_is_400(client):
    response = client.post("/auth/login", json={"username": 123, "password": ["x"]})
    assert response.status_code == 400


def test_api08_protected_endpoint_without_token_is_401(client):
    response = client.post("/accounts", json={})
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "unauthorized"


@pytest.mark.parametrize(
    "header",
    [
        pytest.param("Basic YWxpY2U6cHc=", id="API-09a"),
        pytest.param("Bearer", id="API-09b"),
        pytest.param("Bearer not-a-real-token", id="API-10"),
    ],
)
def test_api09_10_malformed_or_unknown_token_is_401(client, header):
    response = client.get("/accounts/1", headers={"Authorization": header})
    assert response.status_code == 401


def test_api40_sql_injection_style_username_is_rejected_cleanly(client):
    response = client.post("/auth/login", json={"username": "' OR '1'='1", "password": "' OR '1'='1"})
    assert response.status_code == 401
