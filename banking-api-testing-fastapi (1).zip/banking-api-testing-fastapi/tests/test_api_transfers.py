"""API tests: transfers, history, end-to-end flow and performance."""
import time

import pytest


def _transfer(client, headers, src, dst, amount):
    return client.post(
        "/transfers",
        json={"from_account_id": src, "to_account_id": dst, "amount": amount},
        headers=headers,
    )


def test_api26_transfer_at_threshold_has_no_fee(client, alice, bob, make_account):
    a, b = make_account(alice, "2000"), make_account(bob)
    response = _transfer(client, alice, a, b, "1000.00")
    assert response.status_code == 200
    assert response.json()["transfer"]["fee"] == "0.00"


def test_api27_transfer_above_threshold_charges_fee(client, alice, bob, make_account):
    a, b = make_account(alice, "2000"), make_account(bob)
    transfer = _transfer(client, alice, a, b, "1001.00").json()["transfer"]
    assert transfer["fee"] == "5.01"
    assert transfer["from_balance"] == "993.99"


def test_api28_transfer_credits_other_users_account(client, alice, bob, make_account):
    a, b = make_account(alice, "500"), make_account(bob)
    assert _transfer(client, alice, a, b, "200").status_code == 200
    assert client.get(f"/accounts/{b}", headers=bob).json()["balance"] == "200.00"


def test_api29_transfer_with_insufficient_funds_is_422_and_atomic(client, alice, bob, make_account):
    a, b = make_account(alice, "50"), make_account(bob, "5")
    response = _transfer(client, alice, a, b, "50.01")
    assert response.status_code == 422
    assert client.get(f"/accounts/{a}", headers=alice).json()["balance"] == "50.00"
    assert client.get(f"/accounts/{b}", headers=bob).json()["balance"] == "5.00"


def test_api30_transfer_to_same_account_is_400(client, alice, make_account):
    a = make_account(alice, "50")
    assert _transfer(client, alice, a, a, "10").status_code == 400


def test_api31_transfer_from_someone_elses_account_is_403(client, alice, bob, make_account):
    a, b = make_account(alice, "50"), make_account(bob)
    assert _transfer(client, bob, a, b, "10").status_code == 403


def test_api32_transfer_to_missing_account_is_404(client, alice, make_account):
    a = make_account(alice, "50")
    assert _transfer(client, alice, a, 999, "10").status_code == 404


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param({"from_account_id": "1", "to_account_id": 2, "amount": 5}, id="API-33a"),
        pytest.param({"from_account_id": True, "to_account_id": 2, "amount": 5}, id="API-33b"),
        pytest.param({"from_account_id": 1, "to_account_id": 2.5, "amount": 5}, id="API-33c"),
        pytest.param({"from_account_id": 1, "to_account_id": 2}, id="API-34a"),
        pytest.param({"to_account_id": 2, "amount": 5}, id="API-34b"),
        pytest.param({}, id="API-34c"),
    ],
)
def test_api33_34_transfer_with_invalid_or_missing_fields_is_400(client, alice, payload):
    response = client.post("/transfers", json=payload, headers=alice)
    assert response.status_code == 400


def test_api35_transactions_endpoint_lists_history(client, alice, bob, make_account):
    a, b = make_account(alice, "300"), make_account(bob)
    _transfer(client, alice, a, b, "100")
    history = client.get(f"/accounts/{a}/transactions", headers=alice).json()["transactions"]
    assert [t["type"] for t in history] == ["deposit", "transfer_out"]
    assert history[-1]["counterparty"] == b


def test_api36_transactions_of_someone_elses_account_is_403(client, alice, bob, make_account):
    a = make_account(alice, "10")
    assert client.get(f"/accounts/{a}/transactions", headers=bob).status_code == 403


def test_api38_end_to_end_customer_journey(client):
    # login -> open -> deposit -> withdraw -> transfer -> verify both sides
    login = client.post("/auth/login", json={"username": "alice", "password": "wonderland123"})
    alice = {"Authorization": f"Bearer {login.json()['token']}"}
    login = client.post("/auth/login", json={"username": "bob", "password": "builder456"})
    bob = {"Authorization": f"Bearer {login.json()['token']}"}

    a = client.post("/accounts", json={"initial_deposit": "100"}, headers=alice).json()["id"]
    b = client.post("/accounts", json={}, headers=bob).json()["id"]
    client.post(f"/accounts/{a}/deposit", json={"amount": "2000"}, headers=alice)
    client.post(f"/accounts/{a}/withdraw", json={"amount": "50.50"}, headers=alice)
    result = _transfer(client, alice, a, b, "1500").json()["transfer"]

    assert result["fee"] == "7.50"
    assert client.get(f"/accounts/{a}", headers=alice).json()["balance"] == "542.00"
    assert client.get(f"/accounts/{b}", headers=bob).json()["balance"] == "1500.00"
    assert len(client.get(f"/accounts/{a}/transactions", headers=alice).json()["transactions"]) == 4


@pytest.mark.performance
def test_api39_two_hundred_deposits_complete_within_time_budget(client, alice, make_account):
    acct = make_account(alice)
    start = time.perf_counter()
    for _ in range(200):
        assert client.post(f"/accounts/{acct}/deposit", json={"amount": "1.00"}, headers=alice).status_code == 200
    elapsed = time.perf_counter() - start
    assert client.get(f"/accounts/{acct}", headers=alice).json()["balance"] == "200.00"
    assert elapsed < 5.0, f"200 requests took {elapsed:.2f}s"
