"""Unit tests for bank_api.service (no HTTP involved).

Test IDs (UT-xx) map to docs/TEST_CASES.md.
Techniques: EP = equivalence partitioning, BVA = boundary value analysis,
ST = state/transition, DT = decision table, EG = error guessing.
"""
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal

import pytest

from bank_api.service import (
    ForbiddenError,
    InsufficientFundsError,
    NotFoundError,
    ValidationError,
    parse_amount,
)

D = Decimal

VALID_AMOUNTS = [
    pytest.param("0.01", D("0.01"), id="UT-01"),    # BVA: minimum
    pytest.param("50000", D("50000.00"), id="UT-02"),  # BVA: maximum
    pytest.param(100, D("100.00"), id="UT-03"),     # EP: int
    pytest.param(12.5, D("12.50"), id="UT-04"),     # EP: float
    pytest.param(" 7.25 ", D("7.25"), id="UT-05"),  # EP: padded string
]


@pytest.mark.parametrize("raw, expected", VALID_AMOUNTS)
def test_parse_amount_accepts_valid_values(raw, expected):
    result = parse_amount(raw)
    assert result == expected
    assert result.as_tuple().exponent == -2


INVALID_AMOUNTS = [
    pytest.param("0", id="UT-06"),          # BVA: zero
    pytest.param("-0.01", id="UT-07"),      # BVA: just below minimum
    pytest.param("50000.01", id="UT-08"),   # BVA: just above maximum
    pytest.param("1.001", id="UT-09"),      # EP: 3 decimal places
    pytest.param("abc", id="UT-10"),        # EP: non-numeric
    pytest.param(None, id="UT-11"),         # EG: null
    pytest.param(True, id="UT-12"),         # EG: bool is an int in Python
    pytest.param("NaN", id="UT-13"),        # EG: not a number
    pytest.param("Infinity", id="UT-14"),   # EG: infinity
    pytest.param("", id="UT-15"),           # EG: empty string
    pytest.param([1], id="UT-16"),          # EG: wrong type
]


@pytest.mark.parametrize("raw", INVALID_AMOUNTS)
def test_parse_amount_rejects_invalid_values(raw):
    with pytest.raises(ValidationError):
        parse_amount(raw)


def test_ut17_parse_amount_allows_zero_when_requested():
    assert parse_amount("0", allow_zero=True) == D("0.00")


# ---- account lifecycle ---------------------------------------------------
def test_ut18_open_account_defaults_to_zero_balance(bank):
    assert bank.open_account("alice") == {"id": 1, "owner": "alice", "balance": "0.00"}


def test_ut19_open_account_with_initial_deposit_records_history(bank):
    account = bank.open_account("alice", "250.50")
    assert account["balance"] == "250.50"
    history = bank.transactions(account["id"], "alice")
    assert [t["type"] for t in history] == ["deposit"]


def test_ut20_account_ids_increment(bank):
    assert bank.open_account("alice")["id"] == 1
    assert bank.open_account("bob")["id"] == 2


def test_ut21_deposit_increases_balance(bank):
    acct = bank.open_account("alice", "100")["id"]
    bank.deposit(acct, "alice", 25.5)
    assert bank.get_account(acct, "alice")["balance"] == "125.50"


def test_ut22_withdraw_exact_balance_boundary(bank):
    acct = bank.open_account("alice", "100")["id"]
    assert bank.withdraw(acct, "alice", "100")["balance"] == "0.00"


def test_ut23_withdraw_one_cent_over_balance_fails_and_keeps_state(bank):
    acct = bank.open_account("alice", "100")["id"]
    with pytest.raises(InsufficientFundsError):
        bank.withdraw(acct, "alice", "100.01")
    assert bank.get_account(acct, "alice")["balance"] == "100.00"
    assert len(bank.transactions(acct, "alice")) == 1  # only the opening deposit


def test_ut24_partial_withdraw(bank):
    acct = bank.open_account("alice", "100")["id"]
    assert bank.withdraw(acct, "alice", "40.25")["balance"] == "59.75"


# ---- transfers and fee rule ---------------------------------------------
def _two_accounts(bank, alice_balance):
    a = bank.open_account("alice", alice_balance)["id"]
    b = bank.open_account("bob")["id"]
    return a, b


def test_ut25_transfer_at_threshold_has_no_fee(bank):
    a, b = _two_accounts(bank, "2000")
    result = bank.transfer(a, b, "alice", "1000.00")
    assert result["fee"] == "0.00"
    assert result["from_balance"] == "1000.00"
    assert bank.get_account(b, "bob")["balance"] == "1000.00"


def test_ut26_transfer_just_above_threshold_charges_fee(bank):
    a, b = _two_accounts(bank, "2000")
    result = bank.transfer(a, b, "alice", "1000.01")  # 5.00005 -> 5.00
    assert result["fee"] == "5.00"
    assert result["from_balance"] == "994.99"
    assert bank.get_account(b, "bob")["balance"] == "1000.01"  # receiver pays no fee


def test_ut27_fee_rounds_half_up_not_bankers(bank):
    a, b = _two_accounts(bank, "2000")
    assert bank.transfer(a, b, "alice", "1001.00")["fee"] == "5.01"  # 5.005 -> 5.01


def test_ut28_transfer_one_cent_short_including_fee_fails_atomically(bank):
    a, b = _two_accounts(bank, "1006.00")  # needs 1001.00 + 5.01 = 1006.01
    with pytest.raises(InsufficientFundsError):
        bank.transfer(a, b, "alice", "1001.00")
    assert bank.get_account(a, "alice")["balance"] == "1006.00"
    assert bank.get_account(b, "bob")["balance"] == "0.00"


def test_ut29_transfer_with_exactly_enough_for_amount_plus_fee(bank):
    a, b = _two_accounts(bank, "1006.01")
    assert bank.transfer(a, b, "alice", "1001.00")["from_balance"] == "0.00"


def test_ut30_transfer_to_same_account_rejected(bank):
    a = bank.open_account("alice", "100")["id"]
    with pytest.raises(ValidationError):
        bank.transfer(a, a, "alice", "10")


def test_ut31_transfer_to_missing_account_leaves_source_untouched(bank):
    a = bank.open_account("alice", "100")["id"]
    with pytest.raises(NotFoundError):
        bank.transfer(a, 999, "alice", "10")
    assert bank.get_account(a, "alice")["balance"] == "100.00"


def test_ut32_transfer_from_account_you_do_not_own_is_forbidden(bank):
    a, b = _two_accounts(bank, "100")
    with pytest.raises(ForbiddenError):
        bank.transfer(a, b, "bob", "10")
    assert bank.get_account(a, "alice")["balance"] == "100.00"


# ---- access control ------------------------------------------------------
def test_ut33_reading_someone_elses_account_is_forbidden(bank):
    a = bank.open_account("alice")["id"]
    with pytest.raises(ForbiddenError):
        bank.get_account(a, "bob")


def test_ut34_reading_missing_account_is_not_found(bank):
    with pytest.raises(NotFoundError):
        bank.get_account(42, "alice")


# ---- history and concurrency --------------------------------------------
def test_ut35_history_records_every_operation_in_order(bank):
    a, b = _two_accounts(bank, "500")
    bank.withdraw(a, "alice", "100")
    bank.transfer(a, b, "alice", "200")
    history = bank.transactions(a, "alice")
    assert [t["type"] for t in history] == ["deposit", "withdraw", "transfer_out"]
    assert history[-1]["fee"] == "0.00"
    assert history[-1]["balance_after"] == "200.00"
    incoming = bank.transactions(b, "bob")
    assert incoming == [
        {"type": "transfer_in", "amount": "200.00", "balance_after": "200.00", "counterparty": a}
    ]


def test_ut36_concurrent_deposits_do_not_lose_updates(bank):
    a = bank.open_account("alice")["id"]
    with ThreadPoolExecutor(max_workers=16) as pool:
        list(pool.map(lambda _: bank.deposit(a, "alice", "1.00"), range(200)))
    assert bank.get_account(a, "alice")["balance"] == "200.00"
